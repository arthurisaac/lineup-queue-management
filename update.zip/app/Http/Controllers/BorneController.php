<?php

namespace App\Http\Controllers;

use App\Models\Borne;
use Illuminate\Http\Request;
use Inertia\Inertia;

class BorneController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(Borne $borne)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Borne $borne)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Borne $borne)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Borne $borne)
    {
        //
    }
}
